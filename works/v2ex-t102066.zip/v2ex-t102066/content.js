chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	if (request.action == 'download'){
		getAtt();
	}
});

function httpRequest(method, action, query, urlencoded, callback, timeout){
	var url = "GET" == method ? (query ? action+"?"+query : action) : action;
	var timecounter;
	if(this.debug){
		this.outputDebug("httpRequest: method("+method+") action("+action+") query("+query+") urlencoded("+(urlencoded?1:0)+")");
	}

	var xhr = new XMLHttpRequest();
	xhr.open(method, url, true);
	if("POST" == method && urlencoded){
		xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	}
	xhr.onreadystatechange = function() {
	  if (xhr.readyState == 4) {
	  	if(timecounter){
	  		clearTimeout(timecounter);
	  	}
	  	if(this.debug){
	  		this.outputDebug(xhr.responseText);
	  	}
	  	if(callback){
	    	callback(xhr.responseText);
	    }
	  }
	}
	xhr.addEventListener('error', function(){callback(-1)}, false);
	xhr.addEventListener('abort', function(){callback(-2)}, false);
	if("POST" == method && query){
		xhr.send(query);
	}
	else{
		xhr.send();
	}
	if(timeout){
		timecounter = setTimeout(function(){
			if(xhr.readyState != 4){
				xhr.abort();
			}
		}, timeout);
	}
}

function getAtt(){
	alert('下载指令已收到，已经解析出的URL请通过控制台查看。如果下载未自动开始，请耐心等待一段时间或重启浏览器。');
	var a = document.getElementsByTagName('a');
	for(var i=0; i<a.length; i++){
		if(a[i].getAttribute('onclick')){
			getLink(a[i].getAttribute('onclick'));
		}
	}
}

function getLink(click){
	if(click.indexOf('jQuery.get')==-1){
		return;
	}
	var url = click.split('jQuery.get(\'')[1].split('\'')[0];
	url = 'http://bbs.weiphone.com/'+url;
	httpRequest('GET', url, null, false, function(html){
		getUrl(html);
	});
}

function getUrl(html){
	if(html.indexOf('href=')==-1){
		return;
	}
	var url = html.split('href="')[Math.ceil(Math.random()*3)].split('"')[0];
	if(url.indexOf('.attach')==-1){
		return;
	}
	url = 'http://bbs.weiphone.com'+url;
	console.log(url);
	chrome.runtime.sendMessage({'url':url});
}