chrome.browserAction.onClicked.addListener(main);

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
	if (request.url){
		console.log(request.url);
		downloadAtt(request.url);
	}
});

function main(){
	chrome.tabs.query({'active':true},function(tabs){
		console.log(tabs[0].id);
		chrome.tabs.sendMessage(tabs[0].id, {'action':'download'});
	})
}

function downloadAtt(url){
	chrome.downloads.download({
		'url': url,
		'conflictAction': 'uniquify',
		'saveAs': false
	});
}